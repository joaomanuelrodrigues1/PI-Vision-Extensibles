(function (PV) {
	"use strict";

	function symbolVis() { };
	PV.deriveVisualizationFromBase(symbolVis);

	//var dataItem = {
	//	Time: "14-Mar-15 00:00:00",
	//	Value: 100
	//};
	
	var definition = { 
		typeName: "simplevalue",
		visObjectType: symbolVis,
		datasourceBehavior: PV.Extensibility.Enums.DatasourceBehaviors.Single,
		getDefaultConfig: function(){ 
			return { 
				Height: 150,
				Width: 150 
			} 
		}
	}

	symbolVis.prototype.init = function(scope, elem) { 
		
		this.onDataUpdate = dataUpdate
		function dataUpdate(data){
			console.log(data)
			if (data.Label){
				//sporadic
				scope.Label = data.Label;
				scope.Units = data.Units;
				scope.Path = data.Path;
				
			}
			scope.Time = data.Time;
			scope.Value = data.Value;
			scope.Path = data.Path;
		}
	};

	PV.symbolCatalog.register(definition); 
})(window.PIVisualization); 
